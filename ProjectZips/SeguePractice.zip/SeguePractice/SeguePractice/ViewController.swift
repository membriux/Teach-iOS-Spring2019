//
//  ViewController.swift
//  SeguePractice
//
//  Created by Derek Chang on 3/30/19.
//  Copyright © 2019 Derek Chang. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    

    @IBOutlet weak var tableView: UITableView!
    
    
    let numbers = ["1","2","3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
            // Do any additional setup after loading the view, typically from a nib.
    }


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create a new cell that is casted as the specific cell type. Allows us to modify the cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        //change the label of the row according to the 'numbers' array
        cell.label.text = numbers[indexPath.row]
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //check if the segue identifier is correct
        if segue.identifier == "showNumber"{
            //if it is the correct identifier, we know that the sender is a cell because thats how its connected
            let cell = sender as! UITableViewCell
            
            //get the index of the selected cell
            //safe way to unwrap. Sole purpose is to test if an optional variable contains an actual value and bind the non-optional form to a temporary variable
            if let indexPath = tableView.indexPath(for: cell){
                
                //segue parameter gives us access to the destinationViewController
                //In this case, we know that the destinationVC is the 'NumberViewController
                let numberController = segue.destination as! numberViewController
                
                //cannot directly change the text of the label because it did not fully load yet.
                numberController.numberText = numbers[indexPath.row]
                
                tableView.deselectRow(at: indexPath, animated: true)
            }
            
        }
    }
}

