//
//  Cell.swift
//  Flix
//
//  Created by Chase Carnaroli on 4/29/19.
//  Copyright © 2019 Derek Chang. All rights reserved.
//

import Foundation

enum Cell: String {
    case MovieCell
    case MovieGridCell
}
