

## TumblrLab2 Starter Project Steps 

1. **Create PhotoDetailsViewController**
    1. Drag View Controller object
    2. Create PhotoDetailsViewController file
    3. Set the class of the View Controller
2. **Implement properties of PhotoDetailsViewController**
    1. Drag Image View from object library
    2. Connect image view to the file
3. **Embed in Navigation Controller**
    1. Create segue between cell and Photos Details View Controller
    2. Checkpoint: Run Simulator
4. **Implement the prepare() method to pass data**
    1. Write prepareForSegue method in PhotosViewController
